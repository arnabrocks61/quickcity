package com.quick.siti.jpaRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quick.siti.modal.Routes;

public interface RouteRepository extends JpaRepository<Routes, Integer>{
}