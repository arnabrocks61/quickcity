package com.quick.siti.jpaRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quick.siti.modal.BusDetails;


public interface BusDetailsRepository  extends JpaRepository<BusDetails, Integer>{
}