package com.quick.siti.modal;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="bus")
public class Bus {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "BUS_NUMBER")
	private String busNumber;
	
	@Column(name = "BUS_NAME")
	private String busName;
	
	@Column(name = "OWNER_NAME")
	private String ownerName;
	
	@Column(name = "OWNER_MOB")
	private String ownerMob;
	
	@Column(name = "CONDUCTOR_NAME")
	private String conductorName;
	
	@Column(name = "CONDUCTOR_MOB")
	private String conductoMob;
	
	@Column(name = "BUS_DETAILS")
	@OneToMany(mappedBy = "bus", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Set<BusDetails> busDetails;
	
	
	
	public Set<BusDetails> getBusDetails() {
		return busDetails;
	}

	public void setBusDetails(Set<BusDetails> busDetails) {
		this.busDetails = busDetails;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBusNumber() {
		return busNumber;
	}

	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}

	public String getBusName() {
		return busName;
	}

	public void setBusName(String busName) {
		this.busName = busName;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getOwnerMob() {
		return ownerMob;
	}

	public void setOwnerMob(String ownerMob) {
		this.ownerMob = ownerMob;
	}

	public String getConductorName() {
		return conductorName;
	}

	public void setConductorName(String conductorName) {
		this.conductorName = conductorName;
	}

	public String getConductoMob() {
		return conductoMob;
	}

	public void setConductoMob(String conductoMob) {
		this.conductoMob = conductoMob;
	}

	public Bus() {
		
	}

	public Bus(String busNumber, String busName, String ownerName, String ownerMob, String conductorName,
			String conductoMob) {
		super();
		this.busNumber = busNumber;
		this.busName = busName;
		this.ownerName = ownerName;
		this.ownerMob = ownerMob;
		this.conductorName = conductorName;
		this.conductoMob = conductoMob;
		
	}

	



}
